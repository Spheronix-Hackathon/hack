from fastapi import APIRouter
from app.database.mongodb import global_data_async_collection, branches_async_collection

router = APIRouter(prefix="/api", tags=["tasks"])

@router.get("/task-categories")
async def get_task_categories():
    projection = {"_id": 0, "name": 1}
    categories = await global_data_async_collection.find({}, projection).to_list(length=100)
    seen = set()
    category_list = []
    for c in categories:
        name = (c.get("name") or "").strip()
        if name and name.lower() not in seen:
            seen.add(name.lower())
            # Format Ideathon nicely if matched
            if name.lower() == "ideathon":
                category_list.append("Ideathon")
            else:
                category_list.append(name)
    if "ideathon" not in seen:
        category_list.append("Ideathon")
        seen.add("ideathon")
    return category_list

@router.get("/branches")
async def get_branches():
    projection = {"_id": 0, "name": 1}
    branches = await branches_async_collection.find({}, projection).sort("name", 1).to_list(length=100)
    return [b["name"] for b in branches]
