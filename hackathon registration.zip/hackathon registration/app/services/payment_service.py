import asyncio
import logging
import re
import secrets
import urllib.parse
from typing import Optional

from fastapi import HTTPException
from pymongo.errors import DuplicateKeyError

from app.core.time_utils import ist_now, unix_timestamp, utc_now
from app.database.mongodb import async_db, registrations_async_collection
from app.models.schemas import PaymentOrderRequest, PaymentOrderResponse
from app.services.settings_service import get_payment_settings, get_registration_fee
from config.settings import get_settings

settings = get_settings()
logger = logging.getLogger(__name__)


def build_upi_intent_url(upi_id: str, payee_name: str, amount: float, order_id: str = "") -> str:
    clean_upi_id = (upi_id or "334509931804612@CNRB").strip()
    clean_payee = (payee_name or "Spheronix Hackathon").strip()
    encoded_name = urllib.parse.quote(clean_payee)
    encoded_note = urllib.parse.quote("Hackathon Registration Fee")
    amt_str = f"{float(amount):.2f}"
    return f"upi://pay?pa={clean_upi_id}&pn={encoded_name}&am={amt_str}&cu=INR&tn={encoded_note}"


async def verify_upi_payment(order_id: str, utr_number: str) -> dict:
    clean_order_id = (order_id or "").strip()
    clean_utr = re.sub(r"\D", "", (utr_number or "").strip())

    if not clean_order_id:
        raise HTTPException(status_code=400, detail="Order ID is required for payment verification.")

    if len(clean_utr) != 12:
        raise HTTPException(
            status_code=400,
            detail="UTR Number must be exactly 12 numeric digits. Please check your payment receipt.",
        )

    existing_doc = await registrations_async_collection.find_one(
        {"rzp_order_id": clean_order_id},
        {"_id": 1, "payment": 1, "registrationCompleted": 1},
    )

    if not existing_doc:
        raise HTTPException(status_code=404, detail="Payment order not found. Please initiate the payment again.")

    # Update payment document with successful UPI verification
    await registrations_async_collection.update_one(
        {"rzp_order_id": clean_order_id},
        {
            "$set": {
                "payment": {
                    "gateway": "upi",
                    "transaction_id": clean_utr,
                    "status": "success",
                    "utr_number": clean_utr,
                    "timestamp": utc_now(),
                },
                "verifiedAt": utc_now(),
                "updatedAt": utc_now(),
            }
        },
    )

    return {
        "status": "success",
        "message": "UPI payment verified successfully.",
        "order_id": clean_order_id,
        "transaction_id": clean_utr,
        "rzp_order_id": clean_order_id,
        "rzp_payment_id": clean_utr,
    }


async def verify_razorpay_payment(razorpay_order_id: str, razorpay_payment_id: str, razorpay_signature: str) -> dict:
    """Backwards-compatible verification handler for legacy or mock requests."""
    return await verify_upi_payment(razorpay_order_id, razorpay_payment_id or "UPI_TXN_VERIFIED")


async def create_order(request: PaymentOrderRequest) -> PaymentOrderResponse:
    normalized_email = str(request.email).lower()
    selected_task = (request.projectSelected or "").strip()

    existing_registration = await registrations_async_collection.find_one(
        {
            "registrationCompleted": True,
            "$or": [
                {"email": normalized_email},
                {"leader.email": normalized_email},
                {"team_members.email": normalized_email},
            ],
        },
        {"_id": 1, "registrationCompleted": 1},
    )
    if existing_registration:
        raise HTTPException(status_code=409, detail="This email is already registered for the hackathon")

    base_amount = await get_registration_fee()
    if request.participationMode == "team":
        total_members = 1 + request.teamMembersCount
        amount = float(base_amount * total_members)
    else:
        total_members = 1
        amount = float(base_amount)

    total_members = 1 + request.teamMembersCount if request.participationMode == "team" else 1
    update_filter = {"email": normalized_email}
    if existing_registration and existing_registration.get("_id") is not None:
        update_filter = {"_id": existing_registration["_id"]}

    # Check if this order was already created and completed
    existing_doc = await registrations_async_collection.find_one(
        update_filter,
        {"payment": 1, "rzp_order_id": 1, "order_id": 1},
    )
    is_already_paid = existing_doc and str(existing_doc.get("payment", {}).get("status") or "").lower() in [
        "success",
        "paid",
        "captured",
    ]

    saved_order_id = existing_doc.get("order_id") or existing_doc.get("rzp_order_id") if existing_doc else None
    order_id = saved_order_id or f"SPX_UPI_{unix_timestamp()}_{secrets.token_hex(3).upper()}"

    payment_settings = await get_payment_settings()
    upi_id = payment_settings.get("upiId") or "334509931804612@CNRB"
    upi_payee_name = payment_settings.get("upiPayeeName") or "SPHERONIX TECHNOLOGY PVT. LTD."
    bank_name = payment_settings.get("bankName") or "CANARA BANK"
    account_number = payment_settings.get("accountNumber") or "120036804612"
    ifsc_code = payment_settings.get("ifscCode") or "CNRB0000659"
    account_holder_name = payment_settings.get("accountHolderName") or "SPHERONIX TECHNOLOGY PVT. LTD."

    upi_intent_url = build_upi_intent_url(upi_id, upi_payee_name, amount, order_id)

    if is_already_paid:
        return PaymentOrderResponse(
            orderId=order_id,
            amount=amount,
            currency="INR",
            paymentGateway="upi",
            upiId=upi_id,
            upiPayeeName=upi_payee_name,
            bankName=bank_name,
            accountNumber=account_number,
            ifscCode=ifsc_code,
            accountHolderName=account_holder_name,
            upiIntentUrl=upi_intent_url,
            qrCodeData=upi_intent_url,
            totalMembers=total_members,
            feePerMember=base_amount,
            paymentSessionId="",
            environment="PRODUCTION",
            mockMode=True,
            mockPaymentId=existing_doc.get("payment", {}).get("transaction_id") or "already_paid",
            message="Payment already completed",
        )

    update_data = {
        "registrationCompleted": False,
        "email": normalized_email,
        "fullName": request.fullName,
        "participationMode": request.participationMode,
        "mobile": request.mobile,
        "totalMembers": total_members,
        "project_selected": selected_task or None,
        "task_selected": None,
        "rzp_order_id": order_id,
        "order_id": order_id,
        "updatedAt": ist_now(),
        "registeredAt": None,
        "is_reviewed": False,
        "is_selected": False,
        "Reviewedby": None,
        "user_feedback": None,
        "password": "",
        "feedback": "",
        "github_link": "",
        "payment": {
            "gateway": "upi",
            "status": "created",
            "transaction_id": None,
            "amount": amount,
            "currency": "INR",
            "timestamp": ist_now(),
        },
    }

    try:
        await registrations_async_collection.update_one(
            update_filter,
            {
                "$set": update_data,
                "$setOnInsert": {
                    "createdAt": ist_now(),
                },
            },
            upsert=True,
        )

        return PaymentOrderResponse(
            orderId=order_id,
            amount=amount,
            currency="INR",
            paymentGateway="upi",
            upiId=upi_id,
            upiPayeeName=upi_payee_name,
            bankName=bank_name,
            accountNumber=account_number,
            ifscCode=ifsc_code,
            accountHolderName=account_holder_name,
            upiIntentUrl=upi_intent_url,
            qrCodeData=upi_intent_url,
            totalMembers=total_members,
            feePerMember=base_amount,
            paymentSessionId="",
            environment="PRODUCTION",
            mockMode=False,
            mockPaymentId=None,
            message="UPI Payment order created successfully. Scan the QR code or use UPI App to pay.",
        )
    except DuplicateKeyError as exc:
        logger.exception("Mongo duplicate key error while creating payment order")
        raise HTTPException(status_code=409, detail="A unique constraint error occurred. Please try again.")
    except Exception as exc:
        logger.exception(f"Payment order creation failed: {exc}")
        raise HTTPException(
            status_code=500,
            detail="Unable to generate payment order at this moment. Please try again.",
        )
